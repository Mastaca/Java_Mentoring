package arrayListExercise;

import java.util.*;

public class Main {

    /*
    sa cream mai multe masini
    un Owner sa aiba mai multe masini

    citim numarul ownerii si l-e creem
    afisam ownerii
    selectam un owner
    afisam trei posibilitati:   1.afiseaza lista de masin;
                                2. adaugam o masina;
                                3. stergem o masina
                                4. ne intoarcem la lista de owneri
     */

    //TODO sa terminam problema si s-o testam pana MARTI
    //hint: Owner este cheie in HashMap (CNP este unic)

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Please enter the number of owners: ");
        int numberOwners = scan.nextInt();

        Map<Owner, List<Car>> ownersCars = new HashMap<>();

        for (int i = 0; i < numberOwners; i++) {
            System.out.println("Please enter the Owners name: ");
            String name = scan.next();
            System.out.println("Please enter CNP: ");
            long cnp = scan.nextLong();
            Owner owner = new Owner(name, cnp);
            ownersCars.put(owner, new ArrayList<>());
        }
        while(true) {
            showOwners(ownersCars);
            System.out.println("Please select an Owner: ");
            Owner selectedOwner = selectOwner(scan, ownersCars);
            showMenu(scan);
            int selectedOption = scan.nextInt();
            switch (selectedOption) {
                case 1: showCarsList(selectedOwner, ownersCars);
                break;
                case 2: addCar(scan, ownersCars, selectedOwner);
                break;
                case 3: deleteCar(scan, ownersCars, selectedOwner);
                break;
                case 4: showOwners(ownersCars);
                break;
            }

        }
    }

    private static void showCarsList(Owner selectedOwner, Map<Owner, List<Car>> ownersCars) {
        List<Car> cars = ownersCars.get(selectedOwner);
        for (Car car : cars) {
            System.out.println(car.getBrand());
        }
    }

    private static void addCar(Scanner scan, Map<Owner, List<Car>> ownersCars, Owner selectedOwner) {
        System.out.println("Enter Car Brand: ");
        String brand = scan.next();
        System.out.println("Enter Car power: ");
        int power = scan.nextInt();
        Car car = new Car(brand, power);
        List<Car> ownersCarsList = ownersCars.get(selectedOwner);
        ownersCarsList.add(car);
    }

    private static void deleteCar(Scanner scan, Map<Owner, List<Car>> ownersCars, Owner selectedOwner) {
        System.out.println("Enter Car Brand: ");
        String brand = scan.next();
        System.out.println("Enter Car power: ");
        int power = scan.nextInt();
        Car car = new Car(brand, power);
        List<Car> ownersCarsList = ownersCars.get(selectedOwner);
        //TODO sa finalizam metoda
        ownersCarsList.remove(car);
    }

    private static void showMenu(Scanner scan) {
        System.out.println( "1. Afiseaza lista de masin \n" +
                            "2. Adaugam o masina \n" +
                            "3. Stergem o masina\n" +
                            "4. Ne intoarcem la lista de owneri");
    }

    private static Owner selectOwner(Scanner scan, Map<Owner, List<Car>> ownersCars) {
        long selectedOwnerCnp = scan.nextLong();
        for (Owner owner : ownersCars.keySet()) {
            if (owner.getCnp() == selectedOwnerCnp) {
                return owner;
            }
        }
        return null;
    }

    public static void showOwners(Map<Owner, List<Car>> ownerListCars) {
        for( Owner owner : ownerListCars.keySet()) {
            System.out.println(owner.getName() + " " + owner.getCnp());
        }
    }

}
